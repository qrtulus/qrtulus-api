# QRtulus API

Bu repo FastAPI tabanlıdır ve Render üzerinden yayına alınmak için hazırlanmıştır.